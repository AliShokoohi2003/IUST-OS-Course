execute code using below command:
./copy <source_file> <destination_file>
for example you can copy content of source_file.txt to destination_file.txt using this command(in this example source_file.txt and destination_file.txt are in same directory as code):
./copy <source_file.txt> <destination_file.txt>